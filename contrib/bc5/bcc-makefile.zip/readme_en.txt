makefile for CppUnit with Borland C++ 5.5 free compiler

instruction:

- copy this directory 'bcc' under <cppunit>-install dir.

- edit <cppunit>/include/cppunit/config-bcb5.h as follows:

  [1] remove the line:
      #define CPPUNIT_FUNC_STRING_COMPARE_STRING_FIRST  1 
      or replace to:
      #define CPPUNIT_FUNC_STRING_COMPARE_STRING_FIRST  0

  [2] append following lines.

      //-> form here...
      #undef CPPUNIT_API
  
      // define CPPUNIT_DLL_BUILD when building CppUnit dll.
      #ifdef CPPUNIT_BUILD_DLL
      #define CPPUNIT_API __declspec(dllexport)
      #endif
  
      // define CPPUNIT_DLL when linking to CppUnit dll.
      #ifdef CPPUNIT_DLL
      #define CPPUNIT_API __declspec(dllimport)
      #endif
  
      #ifdef CPPUNIT_API
      #undef CPPUNIT_NEED_DLL_DECL
      #define CPPUNIT_NEED_DLL_DECL 1
      #endif
      //<- to here.

- edit <cppunit>/bcc/makefile : 
       line 8: BCB=... 
       line22: CPPUNITV=...

- invoke 'make'

  cppunit_bc5.lib
  cppunitd_bc5.lib
  cppunit_bc5_dll.dll  cppunit_bc5_dll.lib
  cppunitd_bc5_dll.dll cppunitd_bc5_dll.lib

  will be found at <cppunit>/bcc .

($Revision: 1.2 $ $Date: 2002/04/16 09:44:09 $)
